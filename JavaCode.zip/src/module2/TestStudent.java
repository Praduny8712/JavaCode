package module2;
public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student=new Student();
		//student.accept();
		student.display();
		student.attClass();
		student.apperExam();
		student.compAssigment();
		
//		System.out.println("==============");
//		Student student2=new Student();
//		student2.accept();
//		student2.display();
//		student2.attClass();
//		student2.apperExam();
//		student2.compAssigment();
//		
//		System.out.println("==============");
//		Student student3=new Student();
//		student3.accept();
//		student3.display();
//		student3.attClass();
//		student3.apperExam();
//		student3.compAssigment();
//		

	}

}
