package module2;

public class MathDemo {

	public static void main(String[] args) {
		System.out.println(Math.sqrt(144));
		System.out.println(Math.abs(-66));
		System.out.println(Math.min(55,44));
		System.out.println(Math.max(33, 66));
		System.out.println("no is "+Math.random());
		double d= (int)(Math.random()*100);
		System.out.println("s id "+d);
		System.out.println(Math.round(563.6));		
		System.out.println(Math.ceil(898.35));
		System.out.println(Math.floor(898.35));
		System.out.println(Math.pow(2, 2));
	}

}
