package module2;

public class FarmTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Farm Fram1 = new Farm();
		Fram1.acc();
		Fram1.tcName();
		Fram1.loc();
		Fram1.elec();
		Fram1.show();

		System.out.println("=============");
		Farm Fram2 = new Farm();
		Fram2.acc();
		Fram2.tcName();
		Fram2.loc();
		Fram2.elec();
		Fram2.show();

	}

}
