package module1;

import module2.EmpClass;

public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmpClass emp = new EmpClass();
		emp.accept();
		emp.display();
		emp.compleProject();
		emp.checkAttendance();
		emp.applyLoan();


	}

}
