package module1;

public class myclass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		String ename="Praduny";
		double sal=1000.50;
		float comm=10.65f;
		float bono=(float)500.52f;
		byte b=100;
		short s=2000;
		long l =545454545454l;
		char gender='m';
		boolean pasS=true;
		System.out.println("empno is= "+a);
		System.out.println("sal=" +sal);
		System.out.println("comm=" +comm);
		System.out.println("bono=" +bono);
		System.out.println("b=" +b);
		System.out.println("s=" +s);
		System.out.println("l=" +l);
		System.out.println("gender=" +gender);
		System.out.println("PasaS=" +true);
		

	}

}
