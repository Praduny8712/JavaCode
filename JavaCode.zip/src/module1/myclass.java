package module1;

public class myclass {

	public static void main(String Psp[]) {
		// TODO Auto-generated method stub
		System.out.println("Praduny Patil");
		System.out.println("Cdac");
}

}
