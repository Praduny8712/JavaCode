package module3;

public class ForDome {

	public static void main(String[] args) {

		for (int i = 0; i <= 10; i++) {
			System.out.println(i + " = Praduny Patil ");

		}
		int a = 1;
		while (a <= 10) {
			System.out.println(a);
			a++;
		}
		int b = 100;
		do {
			System.out.println(b);
			b++;
		} while (b < 10);

	}
}