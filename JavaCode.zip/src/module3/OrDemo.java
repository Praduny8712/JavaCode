package module3;

public class OrDemo {

	public static void main(String[] args) {
		int a = 1000;
		int b = 100;
		int c = 300;

		if (a == b) {
			System.out.println("Same");
		}
		if (a > b || a > b) {
			System.out.println("one condition is true");
		}
		if (a != b) {
			System.out.println("both are different");
		}

	}

}
